# 快速开始指南

> 新开发者入门 SebeJJ 项目

---

## 🎯 本指南目标

帮助新加入的开发者快速了解项目结构、搭建开发环境并开始贡献代码。

---

## 📋 前置要求

### 必需软件
| 软件 | 版本 | 用途 |
|------|------|------|
| Unity Hub | 最新版 | Unity项目管理 |
| Unity Editor | 2022.3 LTS | 游戏开发 |
| Git | 2.30+ | 版本控制 |
| VS Code / Rider / VS | 最新版 | 代码编辑 |

### 推荐配置
- **操作系统**: Windows 10/11 / macOS 12+ / Linux
- **内存**: 16GB+ (8GB最低)
- **显卡**: 支持DirectX 11
- **存储**: SSD，至少10GB可用空间

---

## 🚀 第一步：项目设置

### 1. 克隆项目仓库

```bash
# 使用HTTPS
git clone <repository-url> sebejj

# 或使用SSH
git clone git@github.com:<org>/sebejj.git

# 进入项目目录
cd sebejj
```

### 2. Unity Hub 打开项目

1. 打开 **Unity Hub**
2. 点击 **Open** → **Add project from disk**
3. 选择 `sebejj` 文件夹
4. 确保使用 **Unity 2022.3 LTS** 版本
5. 点击打开，等待资源导入（首次可能需要10-30分钟）

### 3. 验证项目

打开后检查以下场景是否存在：
- `Assets/Scenes/Boot.unity` - 启动场景
- `Assets/Scenes/MainMenu.unity` - 主菜单
- `Assets/Scenes/Base.unity` - 基地场景
- `Assets/Scenes/Dive.unity` - 下潜场景

点击 **Play** 按钮，确保游戏能正常运行。

---

## 📁 第二步：了解项目结构

### 关键目录位置

```
SebeJJ/
├── 📂 Assets/Scripts/          # 所有游戏代码
│   ├── Core/                   # 核心管理器 (必须了解)
│   ├── Systems/                # 游戏系统
│   ├── Player/                 # 机甲控制
│   ├── Enemies/                # 敌人AI
│   ├── Weapons/                # 武器系统
│   ├── UI/                     # 界面脚本
│   └── Utils/                  # 工具类
│
├── 📂 Assets/Art/              # 美术资源
│   ├── Sprites/                # 精灵图
│   ├── Animations/             # 动画
│   ├── Effects/                # 特效
│   └── StyleGuide/             # 美术规范
│
├── 📂 Assets/Resources/        # 动态加载资源
│   ├── Missions/               # 委托配置(JSON)
│   └── Configs/                # 游戏配置
│
├── 📂 docs/                    # 📚 项目文档
│   ├── GDD.md                  # 游戏设计文档
│   ├── Architecture.md         # 架构文档
│   └── API.md                  # 代码规范
│
└── 📂 Tests/                   # 测试相关
    ├── Documents/              # 测试文档
    └── Reports/                # 测试报告
```

### 关键文件位置

| 文件 | 路径 | 说明 |
|------|------|------|
| GameManager | `Assets/Scripts/Core/GameManager.cs` | 游戏主管理器 |
| MissionManager | `Assets/Scripts/Systems/MissionManager.cs` | 委托系统 |
| MechController | `Assets/Scripts/Player/MechController.cs` | 机甲控制 |
| UIManager | `Assets/Scripts/Core/UIManager.cs` | UI管理器 |
| SaveManager | `Assets/Scripts/Core/SaveManager.cs` | 存档系统 |

---

## 📖 第三步：阅读核心文档

### 必读文档（按顺序）

1. **[README.md](../README.md)**
   - 项目概述
   - 功能特性
   - 操作说明

2. **[docs/GDD.md](GDD.md)**
   - 游戏核心概念
   - 世界观设定
   - 核心系统说明

3. **[docs/Architecture.md](Architecture.md)**
   - 系统架构
   - 数据流
   - 目录结构

4. **[docs/API.md](API.md)**
   - 命名规范
   - 接口定义
   - 最佳实践

### 根据角色选读

**程序开发**
- Architecture.md - 系统架构
- API.md - 代码规范
- Week2_FlowDesign.md - 系统交互流程

**美术制作**
- Assets/Art/StyleGuide/VisualStyleGuide.md - 美术规范
- Assets/Art/Documentation/ - 具体设计文档
- GDD.md - 游戏设计（了解需求）

**测试工程师**
- Tests/Documents/TestPlan.md - 测试计划
- Tests/Documents/QuestTestCases.md - 测试用例
- GDD.md - 了解功能需求

---

## 🛠️ 第四步：常用命令和工具

### Unity 操作

| 操作 | 快捷键/方法 |
|------|-------------|
| 运行游戏 | Ctrl + P / Cmd + P |
| 暂停 | Ctrl + Shift + P |
| 单帧步进 | Ctrl + Alt + P |
| 保存场景 | Ctrl + S |
| 构建 | Ctrl + B |

### Git 常用命令

```bash
# 拉取最新代码
git pull origin develop

# 创建功能分支
git checkout -b feature/your-feature-name

# 提交更改
git add .
git commit -m "feat: 描述你的更改"

# 推送分支
git push origin feature/your-feature-name
```

### 项目脚本

```bash
# 运行测试（如果有）
./tools/run_tests.sh

# 数据导入工具
./tools/DataImporter/import.sh
```

---

## 💻 第五步：开发工作流

### 标准开发流程

```
1. 从 develop 分支创建功能分支
   git checkout develop
   git pull
   git checkout -b feature/xxx

2. 进行开发
   - 编写代码
   - 本地测试
   - 遵循代码规范

3. 提交前检查
   - 代码审查
   - 运行测试
   - 更新文档

4. 提交并推送
   git add .
   git commit -m "type: description"
   git push origin feature/xxx

5. 创建 Pull Request
   - 目标分支: develop
   - 添加审查者
   - 描述更改内容

6. 合并后清理
   git checkout develop
   git pull
   git branch -d feature/xxx
```

### 提交信息规范

```
feat: 新功能
fix: 修复bug
docs: 文档更新
style: 代码格式（不影响功能）
refactor: 重构
test: 测试相关
chore: 构建/工具更改
```

示例：
```bash
git commit -m "feat: 添加机甲冲刺技能"
git commit -m "fix: 修复背包容量计算错误"
git commit -m "docs: 更新API文档"
```

---

## 🔧 第六步：调试技巧

### Unity 调试

1. **断点调试**
   - 在代码行左侧点击设置断点
   - 运行游戏，自动暂停在断点处

2. **日志输出**
   ```csharp
   Debug.Log("普通信息");
   Debug.LogWarning("警告");
   Debug.LogError("错误");
   ```

3. **Inspector 调试**
   - 运行时修改组件属性
   - 查看实时数值变化

### 常见问题

| 问题 | 解决方案 |
|------|----------|
| 资源导入慢 | 删除 Library 文件夹重新导入 |
| 脚本不编译 | 检查 Unity Console 错误 |
| 场景丢失引用 | 检查资源路径，重新赋值 |
| 游戏崩溃 | 查看 Editor.log 定位问题 |

---

## 📚 第七步：学习资源

### 项目内资源

- **docs/** - 所有项目文档
- **Assets/Scripts/Utils/** - 工具类参考
- **Tests/** - 测试示例

### 外部资源

- [Unity 官方文档](https://docs.unity3d.com/)
- [C# 编程指南](https://docs.microsoft.com/zh-cn/dotnet/csharp/)
- [游戏设计模式](https://gameprogrammingpatterns.com/)

---

## ✅ 检查清单

新开发者完成以下任务：

- [ ] 成功克隆并打开项目
- [ ] 能正常运行游戏（点击Play）
- [ ] 阅读 README.md
- [ ] 阅读 GDD.md
- [ ] 阅读 Architecture.md
- [ ] 阅读 API.md（程序）或 美术规范（美术）
- [ ] 了解项目目录结构
- [ ] 知道关键文件位置
- [ ] 成功创建并切换分支
- [ ] 完成第一次提交

---

## 🆘 获取帮助

### 遇到问题？

1. **查看文档** - 先搜索相关文档
2. **检查日志** - Unity Console 和 Editor.log
3. **询问同事** - 在团队频道提问
4. **更新代码** - 确保代码是最新版本

### 联系方式

- **技术问题**: @程序负责人
- **美术问题**: @美术负责人
- **设计问题**: @策划负责人
- **测试问题**: @测试负责人

---

## 🎉 欢迎加入！

现在你已经准备好开始为 SebeJJ 项目贡献代码了。祝你开发愉快！

---

*最后更新: 2026-02-27*
