# SebeJJ 美术资源清单

**项目:** 赛博机甲 SebeJJ  
**版本:** Alpha  
**最后更新:** 2026-02-27

---

## 资源状态图例

- ✅ **已完成** - 已导出并优化
- 🔄 **进行中** - 正在制作或修改
- ⏳ **待开始** - 计划中但未开始
- ❌ **缺失** - 需要创建

---

## 1. 角色动画资源

### 机械鱼 (MechFish)
| 资源名称 | 类型 | 尺寸 | 帧数 | 状态 | 路径 |
|----------|------|------|------|------|------|
| mech_fish_idle | 动画 | 256x256 | 3 | ✅ | Characters/ |
| mech_fish_move | 动画 | 256x256 | 6 | ✅ | Characters/ |
| mech_fish_attack | 动画 | 256x256 | 4 | ✅ | Characters/ |

### 机械蟹 (MechCrab)
| 资源名称 | 类型 | 尺寸 | 帧数 | 状态 | 路径 |
|----------|------|------|------|------|------|
| mech_crab_idle | 动画 | 256x256 | 4 | ✅ | Characters/ |
| mech_crab_move | 动画 | 256x256 | 6 | ✅ | Characters/ |
| mech_crab_defend | 动画 | 256x256 | 2 | ✅ | Characters/ |

### 机械水母 (MechJellyfish)
| 资源名称 | 类型 | 尺寸 | 帧数 | 状态 | 路径 |
|----------|------|------|------|------|------|
| mech_jellyfish_idle | 动画 | 256x256 | 3 | ✅ | Characters/ |
| mech_jellyfish_move | 动画 | 256x256 | - | ⏳ | - |
| mech_jellyfish_attack | 动画 | 256x256 | - | ⏳ | - |

### 机械鲨鱼 (MechShark)
| 资源名称 | 类型 | 尺寸 | 帧数 | 状态 | 路径 |
|----------|------|------|------|------|------|
| mech_shark_idle | 动画 | 256x256 | - | ❌ | - |
| mech_shark_move | 动画 | 256x256 | - | ❌ | - |
| mech_shark_attack | 动画 | 256x256 | - | ❌ | - |

### 机械章鱼 (MechOctopus)
| 资源名称 | 类型 | 尺寸 | 帧数 | 状态 | 路径 |
|----------|------|------|------|------|------|
| mech_octopus_idle | 动画 | 256x256 | - | ❌ | - |
| mech_octopus_move | 动画 | 256x256 | - | ❌ | - |
| mech_octopus_attack | 动画 | 256x256 | - | ❌ | - |

### Boss - 深渊巨兽
| 资源名称 | 类型 | 尺寸 | 帧数 | 状态 | 路径 |
|----------|------|------|------|------|------|
| boss_abyss_idle | 动画 | 512x512 | - | ❌ | - |
| boss_abyss_attack | 动画 | 512x512 | - | ❌ | - |
| boss_abyss_phase2 | 动画 | 512x512 | - | ❌ | - |

---

## 2. 玩家机甲资源

| 资源名称 | 类型 | 尺寸 | 状态 | 路径 |
|----------|------|------|------|------|
| Mecha_Mk1_Base | 静态 | 256x256 | ✅ | Characters/ |
| Mecha_Mk1_Anim_Idle | 动画 | 256x64 | ✅ | Animations/ |
| Mecha_Mk1_Anim_Move | 动画 | 256x43 | ✅ | Animations/ |
| Mecha_Mk1_Anim_Hit | 动画 | 256x85 | ✅ | Animations/ |
| Mecha_Mk1_Anim_Collect | 动画 | 256x43 | ✅ | Animations/ |
| Mecha_Idle_Sprites | 精灵图 | 256x64 | ✅ | Animations/ |
| Mecha_Move_Sprites | 精灵图 | 256x43 | ✅ | Animations/ |
| Mecha_Hit_Sprites | 精灵图 | 256x85 | ✅ | Animations/ |
| Mecha_Drill_Sprites | 精灵图 | 256x37 | ✅ | Animations/ |

---

## 3. 特效资源

### 击中特效
| 资源名称 | 尺寸 | 状态 | 路径 |
|----------|------|------|------|
| fx_hit_spark | 128x128 | ✅ | Effects/ |
| fx_shield_impact | 256x256 | ✅ | Effects/ |
| fx_enemy_fish_hit | 128x128 | ✅ | Effects/ |
| FX_Hit | 128x43 | ✅ | FX/ |
| FX_Hit_Effect | 128x43 | ✅ | FX/ |

### 爆炸特效
| 资源名称 | 尺寸 | 状态 | 路径 |
|----------|------|------|------|
| fx_explosion_small | 256x256 | ✅ | Effects/ |
| fx_enemy_death_explosion | 256x256 | ✅ | Effects/ |
| fx_laser_explosion | 256x256 | ✅ | Effects/ |

### 护盾特效
| 资源名称 | 尺寸 | 状态 | 路径 |
|----------|------|------|------|
| fx_enemy_crab_shield | 256x256 | ✅ | Effects/ |

### 武器特效
| 资源名称 | 尺寸 | 状态 | 路径 |
|----------|------|------|------|
| fx_laser_beam | 128x128 | ✅ | Effects/ |
| fx_drill_spark | 128x128 | ✅ | Effects/ |
| fx_drill_trail | 128x128 | ✅ | Effects/ |
| fx_claw_tear | 128x128 | ✅ | Effects/ |
| fx_thruster_flame | 128x128 | ✅ | Effects/ |

### 环境特效
| 资源名称 | 尺寸 | 状态 | 路径 |
|----------|------|------|------|
| fx_bubble_trail | 128x128 | ✅ | Effects/ |
| fx_depth_pressure | 128x128 | ✅ | Effects/ |
| FX_Bubble_Trail | 128x32 | ✅ | FX/ |
| FX_BubbleTrail | 128x32 | ✅ | FX/ |
| FX_Bubbles | 128x128 | ✅ | FX/ |

### 物品特效
| 资源名称 | 尺寸 | 状态 | 路径 |
|----------|------|------|------|
| fx_item_drop_glow | 128x128 | ✅ | Effects/ |
| fx_item_pickup | 128x128 | ✅ | Effects/ |
| FX_Collect | 128x43 | ✅ | FX/ |
| FX_Collect_Effect | 128x43 | ✅ | FX/ |
| FX_Glow_Collection | 128x128 | ✅ | FX/ |

### 敌人特效
| 资源名称 | 尺寸 | 状态 | 路径 |
|----------|------|------|------|
| fx_enemy_jellyfish_electric | 128x128 | ✅ | Effects/ |
| FX_Scan_Wave | 128x128 | ✅ | FX/ |

---

## 4. UI资源

### 状态条
| 资源名称 | 尺寸 | 状态 | 路径 |
|----------|------|------|------|
| ui_health_bar | 400x100 | ✅ | UI/ |
| ui_energy_bar | 400x100 | ✅ | UI/ |
| ui_oxygen_bar | 400x100 | ✅ | UI/ |

### 面板
| 资源名称 | 尺寸 | 状态 | 路径 |
|----------|------|------|------|
| UI_Panel_Basic | 800x800 | ✅ | Backgrounds/ |
| UI_Panel_Inventory | 819x1024 | ✅ | Backgrounds/ |
| Contract_Board | 512x288 | ✅ | UI/ |
| UI_QuestBoard | 512x384 | ✅ | UI/ |
| UI_Cargo_Slot | 250x250 | ✅ | Backgrounds/ |

### HUD
| 资源名称 | 尺寸 | 状态 | 路径 |
|----------|------|------|------|
| UI_HUD_Framework | 512x288 | ✅ | UI/ |
| UI_Depth_Meter | 307x1024 | ✅ | Backgrounds/ |

### 菜单
| 资源名称 | 尺寸 | 状态 | 路径 |
|----------|------|------|------|
| MainMenu_Design | 512x288 | ✅ | UI/ |

---

## 5. 武器资源

| 资源名称 | 尺寸 | 状态 | 路径 |
|----------|------|------|------|
| weapon_icon_claw | 64x64 | ✅ | Weapons/ |
| weapon_icon_drill | 64x64 | ✅ | Weapons/ |
| weapon_icon_laser | 64x64 | ✅ | Weapons/ |

---

## 6. 物品资源

| 资源名称 | 尺寸 | 状态 | 路径 |
|----------|------|------|------|
| ITM_Resources_Common | 64x64 | ✅ | Items/ |
| Resource_Icons | 128x9 | ✅ | Items/ |

---

## 7. 背景资源

### 地形背景
| 资源名称 | 尺寸 | 状态 | 路径 |
|----------|------|------|------|
| BG_100m_Terrain | 1024x576 | ✅ | Backgrounds/ |
| BG_500m_Terrain | 1024x576 | ✅ | Backgrounds/ |
| BG_DeepSea_1000m | 1024x576 | ✅ | Backgrounds/ |
| BG_2000m_Ruins | 1024x576 | ✅ | Backgrounds/ |
| BG_Terrain_1000m | 512x512 | ✅ | Environment/ |

### 视差背景
| 资源名称 | 尺寸 | 状态 | 路径 |
|----------|------|------|------|
| Parallax_Far | 1024x576 | ✅ | Backgrounds/ |
| Parallax_Mid | 1024x576 | ✅ | Backgrounds/ |
| Parallax_Near | 1024x576 | ✅ | Backgrounds/ |

### 矿脉
| 资源名称 | 尺寸 | 状态 | 路径 |
|----------|------|------|------|
| Vein_Copper | 400x400 | ✅ | Backgrounds/ |
| Vein_Iron | 400x400 | ✅ | Backgrounds/ |
| Vein_Gold | 400x400 | ✅ | Backgrounds/ |
| Vein_Titanium | 400x400 | ✅ | Backgrounds/ |

---

## 8. 环境资源

| 资源名称 | 尺寸 | 状态 | 路径 |
|----------|------|------|------|
| PROP_Rock_Formations | 512x512 | ✅ | Environment/ |
| PROP_Shipwrecks | 512x512 | ✅ | Environment/ |

---

## 9. 精灵图集

| 资源名称 | 尺寸 | 包含内容 | 状态 | 路径 |
|----------|------|----------|------|------|
| Characters_Atlas | 7424x256 | 所有角色帧 | ✅ | Atlases/ |
| Animations_Atlas | 2048x85 | 动画精灵图 | ✅ | Atlases/ |
| Effects_Atlas | 2816x256 | 所有特效 | ✅ | Atlases/ |
| FX_Atlas | 1152x128 | FX粒子 | ✅ | Atlases/ |
| Weapons_Atlas | 192x64 | 武器图标 | ✅ | Atlases/ |
| Items_Atlas | 128x9 | 物品图标 | ✅ | Atlases/ |

---

## 10. 资源统计

### 按类别统计
| 类别 | 已完成 | 进行中 | 待开始 | 缺失 | 总计 |
|------|--------|--------|--------|------|------|
| 角色动画 | 30 | 0 | 9 | 12 | 51 |
| 玩家机甲 | 9 | 0 | 0 | 0 | 9 |
| 特效 | 26 | 0 | 0 | 0 | 26 |
| UI | 9 | 0 | 0 | 0 | 9 |
| 武器 | 3 | 0 | 0 | 0 | 3 |
| 物品 | 2 | 0 | 0 | 0 | 2 |
| 背景 | 11 | 0 | 0 | 0 | 11 |
| 环境 | 2 | 0 | 0 | 0 | 2 |
| 图集 | 6 | 0 | 0 | 0 | 6 |
| **总计** | **98** | **0** | **9** | **12** | **119** |

### 完成度
- **已完成:** 82.4% (98/119)
- **进行中:** 0% (0/119)
- **待开始:** 7.6% (9/119)
- **缺失:** 10.1% (12/119)

---

## 11. 缺失资源优先级

### 高优先级 (Boss战需要)
1. boss_abyss_idle - 深渊巨兽待机动画
2. boss_abyss_attack - 深渊巨兽攻击动画
3. boss_abyss_phase2 - 深渊巨兽二阶段

### 中优先级 (敌人多样性)
4. mech_shark_idle - 机械鲨鱼待机
5. mech_shark_move - 机械鲨鱼移动
6. mech_shark_attack - 机械鲨鱼攻击
7. mech_octopus_idle - 机械章鱼待机
8. mech_octopus_move - 机械章鱼移动
9. mech_octopus_attack - 机械章鱼攻击

### 低优先级 (完善内容)
10. mech_jellyfish_move - 水母移动
11. mech_jellyfish_attack - 水母攻击

---

**清单维护:** 美术资源工程师  
**下次审查:** 2026-03-06
