# SebeJJ 赛博机甲 - 系统地图

> 项目技术架构全景图 - 快速导航文档
> 生成时间: 2026-02-27

---

## 🗺️ 系统全景图

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           SebeJJ 赛博机甲 - 系统地图                          │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                        🎮 核心层 (Core)                             │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │   │
│  │  │ GameManager  │  │ SaveManager  │  │  UIManager   │              │   │
│  │  │   游戏管理器  │  │   存档管理器  │  │   UI管理器   │              │   │
│  │  └──────────────┘  └──────────────┘  └──────────────┘              │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │   │
│  │  │ EventSystem  │  │ConfigManager │  │ServiceLocator│              │   │
│  │  │   事件系统    │  │   配置管理器  │  │   服务定位器  │              │   │
│  │  └──────────────┘  └──────────────┘  └──────────────┘              │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                       📋 系统层 (Systems)                           │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │   │
│  │  │MissionManager│  │ResourceManager│  │ DiveManager  │              │   │
│  │  │   委托管理器  │  │   资源管理器  │  │   下潜管理器  │              │   │
│  │  └──────────────┘  └──────────────┘  └──────────────┘              │   │
│  │  ┌──────────────┐  ┌──────────────┐                               │   │
│  │  │MissionTracker│  │  GameData    │                               │   │
│  │  │   委托追踪器  │  │   游戏数据   │                               │   │
│  │  └──────────────┘  └──────────────┘                               │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                       ⚔️ 战斗系统 (Combat)                          │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │   │
│  │  │CombatManager │  │DamageCalculator│  │CombatFeedback│             │   │
│  │  │   战斗管理器  │  │   伤害计算器   │  │   战斗反馈   │              │   │
│  │  └──────────────┘  └──────────────┘  └──────────────┘              │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │   │
│  │  │ DefenseSystem│  │ ShieldSystem │  │ ArmorSystem  │              │   │
│  │  │   防御系统    │  │   护盾系统    │  │   护甲系统    │              │   │
│  │  └──────────────┘  └──────────────┘  └──────────────┘              │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │   │
│  │  │  WeaponBase  │  │ MeleeWeapon  │  │ RangedWeapon │              │   │
│  │  │   武器基类    │  │   近战武器    │  │   远程武器    │              │   │
│  │  └──────────────┘  └──────────────┘  └──────────────┘              │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                       🤖 AI系统 (AI)                                │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │   │
│  │  │AIStateMachine│  │ AIPerception │  │AStarPathfinding│            │   │
│  │  │   状态机核心  │  │   感知系统    │  │   A*寻路      │              │   │
│  │  └──────────────┘  └──────────────┘  └──────────────┘              │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │   │
│  │  │   IAIState   │  │ AIStateBase  │  │ PathFollower │              │   │
│  │  │   状态接口    │  │   状态基类    │  │   路径跟随    │              │   │
│  │  └──────────────┘  └──────────────┘  └──────────────┘              │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │   │
│  │  │  EnemyBase   │  │ MechFishAI   │  │ MechCrabAI   │              │   │
│  │  │   敌人基类    │  │   机械鱼AI    │  │   机械蟹AI    │              │   │
│  │  └──────────────┘  └──────────────┘  └──────────────┘              │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                       👤 玩家系统 (Player)                          │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │   │
│  │  │MechController│  │ MechMovement │  │MechCollector │              │   │
│  │  │   机甲控制器  │  │   机甲移动    │  │   机甲采集    │              │   │
│  │  └──────────────┘  └──────────────┘  └──────────────┘              │   │
│  │  ┌──────────────┐  ┌──────────────┐                               │   │
│  │  │CombatStats   │  │CollectibleResource│                           │   │
│  │  │   战斗属性    │  │   可采集资源    │                               │   │
│  │  └──────────────┘  └──────────────┘                               │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                       🎨 UI系统 (UI)                                │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │   │
│  │  │ UIAnimation  │  │ HUDController│  │ MenuSystem   │              │   │
│  │  │   UI动画     │  │   HUD控制器   │  │   菜单系统    │              │   │
│  │  └──────────────┘  └──────────────┘  └──────────────┘              │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │   │
│  │  │DamageNumber  │  │HealthBarAnim │  │QuestBoardAnim│              │   │
│  │  │   伤害数字    │  │   血条动画    │  │   委托板动画  │              │   │
│  │  └──────────────┘  └──────────────┘  └──────────────┘              │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                       🔧 工具系统 (Utils)                           │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │   │
│  │  │AudioManagerEx│  │EffectManager │  │  GameUtils   │              │   │
│  │  │   音频管理器  │  │   特效管理器  │  │   游戏工具    │              │   │
│  │  └──────────────┘  └──────────────┘  └──────────────┘              │   │
│  │  ┌──────────────┐  ┌──────────────┐                               │   │
│  │  │  GameEvents  │  │ ObjectPool   │                               │   │
│  │  │   游戏事件    │  │   对象池     │                               │   │
│  │  └──────────────┘  └──────────────┘                               │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                       🔗 集成层 (Integration)                       │   │
│  │  ┌──────────────────┐  ┌──────────────────┐  ┌──────────────────┐  │   │
│  │  │CombatIntegration │  │ CombatSceneManager│  │  LootDropSystem  │  │   │
│  │  │   战斗集成系统    │  │   战斗场景管理器   │  │   战利品掉落系统  │  │   │
│  │  └──────────────────┘  └──────────────────┘  └──────────────────┘  │   │
│  │  ┌──────────────────┐  ┌──────────────────┐                       │   │
│  │  │MechCombatController│  │ TestSceneSpawner │                       │   │
│  │  │   机甲战斗控制器   │  │   测试场景生成器   │                       │   │
│  │  └──────────────────┘  └──────────────────┘                       │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                       👹 Boss系统 (Boss)                            │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │   │
│  │  │IronClawBeast │  │  BossStates  │  │  BossArena   │              │   │
│  │  │   铁爪巨兽    │  │   Boss状态   │  │   Boss战场   │              │   │
│  │  └──────────────┘  └──────────────┘  └──────────────┘              │   │
│  │  ┌──────────────┐  ┌──────────────┐                               │   │
│  │  │BossHealthBar │  │CombatWarning │                               │   │
│  │  │   Boss血条    │  │   战斗预警   │                               │   │
│  │  └──────────────┘  └──────────────┘                               │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
│  ┌─────────────────────────────────────────────────────────────────────┐   │
│  │                       🎯 体验系统 (Experience)                      │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │   │
│  │  │DifficultyMgr │  │TutorialManager│  │PacingManager │              │   │
│  │  │   难度管理器  │  │   教程管理器  │  │   节奏管理器  │              │   │
│  │  └──────────────┘  └──────────────┘  └──────────────┘              │   │
│  │  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐              │   │
│  │  │PlayerJourney │  │PainPointDet  │  │  ABTestMgr   │              │   │
│  │  │   玩家旅程    │  │   痛点检测    │  │   AB测试     │              │   │
│  │  └──────────────┘  └──────────────┘  └──────────────┘              │   │
│  └─────────────────────────────────────────────────────────────────────┘   │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

---

## 📁 目录结构

```
projects/sebejj/
├── Assets/
│   └── Scripts/
│       ├── Core/                    # 核心系统
│       │   ├── GameManager.cs
│       │   ├── SaveManager.cs
│       │   ├── UIManager.cs
│       │   ├── EventSystem.cs
│       │   ├── ConfigManager.cs
│       │   └── ServiceLocator.cs
│       │
│       ├── Systems/                 # 游戏系统
│       │   ├── MissionManager.cs
│       │   ├── MissionData.cs
│       │   ├── MissionTracker.cs
│       │   ├── ResourceManager.cs
│       │   └── DiveManager.cs
│       │
│       ├── Combat/                  # 战斗系统
│       │   ├── CombatManager.cs
│       │   ├── DamageCalculator.cs
│       │   ├── DamageInfo.cs
│       │   ├── CombatFeedback.cs
│       │   ├── DefenseSystem.cs
│       │   ├── ShieldSystem.cs
│       │   ├── ArmorSystem.cs
│       │   ├── WeaponBase.cs
│       │   ├── MeleeWeapon.cs
│       │   ├── RangedWeapon.cs
│       │   └── WeaponComboSystem.cs
│       │
│       ├── AI/                      # AI系统
│       │   ├── AIStateMachine.cs
│       │   ├── IAIState.cs
│       │   ├── AIPerception.cs
│       │   ├── AStarPathfinding.cs
│       │   ├── PathFollower.cs
│       │   └── EnemyHitReaction.cs
│       │
│       ├── Enemies/                 # 敌人
│       │   ├── EnemyBase.cs
│       │   ├── MechFishAI.cs
│       │   ├── MechCrabAI.cs
│       │   ├── MechJellyfishAI.cs
│       │   ├── DeepOctopus.cs
│       │   └── MechShark.cs
│       │
│       ├── Boss/                    # Boss系统
│       │   ├── IronClawBeastBoss.cs
│       │   ├── BossStates.cs
│       │   ├── BossArena.cs
│       │   ├── BossHealthBar.cs
│       │   └── CombatWarningSystem.cs
│       │
│       ├── Player/                  # 玩家系统
│       │   ├── MechController.cs
│       │   ├── MechMovement.cs
│       │   ├── MechCollector.cs
│       │   └── CollectibleResource.cs
│       │
│       ├── Weapons/                 # 武器系统
│       │   ├── Chainsaw.cs
│       │   ├── ChainsawData.cs
│       │   ├── EMPWeapon.cs
│       │   ├── EMPData.cs
│       │   ├── PlasmaCannon.cs
│       │   ├── PlasmaCannonData.cs
│       │   └── PlasmaProjectile.cs
│       │
│       ├── UI/                      # UI系统
│       │   └── Animation/
│       │       ├── HealthBarAnimator.cs
│       │       ├── DamageNumberAnimator.cs
│       │       ├── QuestBoardAnimator.cs
│       │       └── ...
│       │
│       ├── Data/                    # 数据定义
│       │   └── GameData.cs
│       │
│       ├── Utils/                   # 工具类
│       │   ├── AudioManagerExtended.cs
│       │   ├── EffectManager.cs
│       │   ├── GameUtils.cs
│       │   └── GameEvents.cs
│       │
│       ├── Integration/             # 集成层
│       │   ├── CombatIntegrationSystem.cs
│       │   ├── CombatSceneManager.cs
│       │   ├── LootDropSystem.cs
│       │   └── MechCombatController.cs
│       │
│       └── Experience/              # 体验系统
│           ├── Difficulty/
│           │   ├── DifficultyManager.cs
│           │   ├── EnemyScalingSystem.cs
│           │   └── DeathPenaltySystem.cs
│           ├── Tutorial/
│           │   ├── TutorialManager.cs
│           │   └── TutorialStep.cs
│           ├── Pacing/
│           │   ├── PacingManager.cs
│           │   └── SavePointSystem.cs
│           └── Analytics/
│               ├── PlayerJourneyTracker.cs
│               └── PainPointDetector.cs
│
├── docs/
│   ├── Architecture/                # 架构文档
│   │   ├── ARCHITECTURE.md          # 完整架构图
│   │   └── SYSTEM_MAP.md            # 系统地图(本文件)
│   ├── GDD.md                       # 游戏设计文档
│   ├── API.md                       # API文档
│   └── ...
│
├── src/                             # 源代码(编辑器脚本等)
├── tests/                           # 测试代码
└── tools/                           # 工具脚本
```

---

## 🔗 关键系统关系

### 核心依赖链

```
GameManager (单例根节点)
    ├── SaveManager ──→ 文件系统
    ├── UIManager ────→ Canvas/面板
    ├── MissionManager ──→ MissionData (SO)
    ├── ResourceManager ──→ 玩家资源
    └── DiveManager ──→ CombatManager

CombatManager
    ├── DamageCalculator ──→ DefenseSystem/ShieldSystem
    ├── CombatFeedback ──→ EffectManager/AudioManager
    └── WeaponManager ──→ WeaponBase派生类

AIStateMachine
    ├── AIPerception ──→ 目标检测
    ├── AStarPathfinding ──→ 路径计算
    └── IAIState ──→ 具体状态实现
```

### 事件流

```
游戏事件 (EventSystem)
    ├── OnGameStateChanged ──→ UI更新
    ├── OnMissionCompleted ──→ 奖励发放
    ├── OnCombatStart/End ──→ 音乐/特效
    ├── OnDamageDealt ──→ 伤害数字
    └── OnEnemyDeath ──→ 掉落/击杀反馈
```

---

## 📊 代码统计

| 模块 | 文件数 | 主要功能 |
|------|--------|----------|
| Core | 6 | 游戏核心管理 |
| Systems | 6 | 委托/资源/下潜 |
| Combat | 15+ | 战斗/伤害/武器 |
| AI | 10+ | 状态机/感知/寻路 |
| Enemies | 5 | 敌人AI实现 |
| Boss | 6 | Boss系统 |
| Player | 4 | 玩家控制 |
| Weapons | 7 | 武器实现 |
| UI | 17 | UI动画系统 |
| Utils | 4 | 工具类 |
| Integration | 6 | 系统集成 |
| Experience | 12 | 体验优化 |
| **总计** | **~132** | **完整游戏系统** |

---

## 🎯 快速导航

### 按功能查找

| 功能 | 主要文件 |
|------|----------|
| **存档系统** | `Core/SaveManager.cs` |
| **委托系统** | `Systems/MissionManager.cs`, `Systems/MissionData.cs` |
| **伤害计算** | `Combat/DamageCalculator.cs`, `Combat/DamageInfo.cs` |
| **战斗反馈** | `Combat/CombatFeedback.cs` |
| **AI状态机** | `AI/AIStateMachine.cs`, `AI/IAIState.cs` |
| **感知系统** | `AI/AIPerception.cs` |
| **寻路系统** | `AI/AStarPathfinding.cs` |
| **武器系统** | `Combat/WeaponBase.cs`, `Weapons/*.cs` |
| **UI动画** | `UI/Animation/*.cs` |
| **Boss系统** | `Boss/IronClawBeastBoss.cs`, `Boss/BossStates.cs` |

### 按任务ID查找

| 任务ID | 相关文件 |
|--------|----------|
| AI-001~003 | `AI/AIStateMachine.cs`, `AI/IAIState.cs` |
| AI-004~005 | `AI/AIPerception.cs` |
| CB-001~004 | `Combat/CombatManager.cs` |
| DM-001~004 | `Combat/DamageCalculator.cs`, `Combat/DamageInfo.cs` |
| FB-001~006 | `Combat/CombatFeedback.cs` |
| SV-001~006 | `Core/SaveManager.cs` |
| BUG-003 | `Systems/MissionManager.cs` |
| BUG-005 | `Core/UIManager.cs` |

---

## 📝 文档索引

| 文档 | 路径 | 说明 |
|------|------|------|
| 架构图 | `docs/Architecture/ARCHITECTURE.md` | 完整Mermaid架构图 |
| 系统地图 | `docs/Architecture/SYSTEM_MAP.md` | 本文件 |
| 游戏设计 | `docs/GDD.md` | GDD文档 |
| API文档 | `docs/API.md` | 代码规范 |
| 开发计划 | `docs/DevelopmentPlan.md` | 项目计划 |
| 进度报告 | `docs/Progress.md` | 当前进度 |

---

*文档版本: 1.0*
*最后更新: 2026-02-27*
*作者: 架构可视化工程师*
